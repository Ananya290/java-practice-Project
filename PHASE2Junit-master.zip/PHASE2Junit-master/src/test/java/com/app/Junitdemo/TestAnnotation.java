package com.app.Junitdemo;

import org.junit.jupiter.api.Test;

public class TestAnnotation {

	
	@Test
	
	public void method1() {
		System.out.println("hello");
	}
}
