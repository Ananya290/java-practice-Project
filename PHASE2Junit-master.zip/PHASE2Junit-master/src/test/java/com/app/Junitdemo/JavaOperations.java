package com.app.Junitdemo;

public class JavaOperations {

}
