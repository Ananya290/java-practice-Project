package restassureScript;

public class Hamcrestdemomethod {
	
	
	
	

}
