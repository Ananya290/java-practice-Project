package testNG1;

import org.testng.annotations.Test;

public class TESTNGDEMO1 {
    @Test
	public void method1(){
		
	}
}
