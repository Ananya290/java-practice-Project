package gradleProject;

import org.junit.jupiter.api.Test;

public class DemoTest {

	
	@Test
	public void gradledemo() {
		System.out.println("demo");	}
}
